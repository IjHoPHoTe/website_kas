
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Form Edit Wilayah</h6>
    </div>
    <form action="<?php echo e(url('update_wilayah/' . $wilayah->id)); ?>" method="POST">
    <div class="card-body">
            <?php echo e(csrf_field()); ?>

        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nama Wilayah</label>
            <input type="text" class="form-control" value="<?php echo e($wilayah->nama_wilayah); ?>" name="nama_wilayah" id="exampleFormControlInput1" placeholder="Masukkan Nama">
        </div>
    </div>
    <div class="card-footer">
        <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Titipan\website_kas\resources\views/admin/wilayah/edit_wilayah.blade.php ENDPATH**/ ?>