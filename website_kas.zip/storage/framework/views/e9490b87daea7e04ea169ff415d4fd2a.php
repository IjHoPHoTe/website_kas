<?php $__env->startSection('content'); ?>

<!-- Content Row -->
<div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-md-4 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Sisa Kas</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.<?php echo e($sisaKas); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-wallet fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-md-4 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Kas Masuk</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.<?php echo e($totalKasMasuk); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-angle-double-up fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <!-- Pending Requests Card Example -->
    <div class="col-md-4 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Kas Keluar</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">Rp.<?php echo e($totalKasKeluar); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-angle-double-down fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <!-- Color System -->
 <div class="row">
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white shadow">
            <div class="card-body">
                Anggota
                <div class="text-white-50 small">#4e73df</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white shadow">
            <div class="card-body">
                Wilayah
                <div class="text-white-50 small">#1cc88a</div>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card bg-info text-white shadow">
            <div class="card-body">
                Komisariat
                <div class="text-white-50 small">#1cc88a</div>
            </div>
        </div>
    </div>
</div>

</div>

<!-- Content Row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website_kas\website_kas\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>