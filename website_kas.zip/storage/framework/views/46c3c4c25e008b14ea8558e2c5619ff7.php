<?php $__env->startSection('content'); ?>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 ">
            <h6 class=" font-weight-bold text-primary">Data Anggota</h6>
            <div class="float-right">
                <a href="/add_murid" class="btn btn-info btn-circle">
                    <i class="fas fa-plus-circle"></i>
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-hover">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Anggota</th>
                            <th>Nama</th>
                            <th>Wilayah</th>
                            <th>Komisariat</th>
                            <th>Alamat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($m->id_anggota); ?></td>
                                <td><?php echo e($m->nama); ?></td>
                                <td><?php echo e($m->wilayah->nama_wilayah); ?></td>
                                <td><?php echo e($m->komisariat->nama_komisariat); ?></td>
                                <td><?php echo e($m->alamat); ?></td>
                                <td>

                                    
                                    <a href="<?php echo e(route('edit.murid', $m->id)); ?>">
                                        <i class="nav-icon fas fa-edit"></i>
                                    </a>
                                    |
                                    <a href="<?php echo e(url('delete', $m->id)); ?>">
                                        <i class="nav-icon fas fa-trash" style="color: red"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website_kas\website_kas\resources\views/admin/murid/murid.blade.php ENDPATH**/ ?>