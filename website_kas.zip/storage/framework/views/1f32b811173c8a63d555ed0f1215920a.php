<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Laporan Kas</h6>
    </div>
    <form action="<?php echo e(route('wilayah.store')); ?>" method="post">
    <div class="card-body">
            <?php echo e(csrf_field()); ?>


    <div class="row">
        <div class="col-md-4 mb-4">
            <label for="id_wilayah" class="form-label">Kategori</label>
                    <select class="form-control" name="jenis">
                        <option value="semua">Semua</option>
                        <option value="masuk">Kas Masuk</option>
                        <option value="keluar">Kas Keluar</option>
                    </select>
        </div>

        <div class="col-md-4 mb-4">
            <label for="exampleFormControlInput1" class="form-label">Tanggal Awal</label>
            <input type="date" class="form-control" name="nama_wilayah" id="exampleFormControlInput1" placeholder="Masukkan Nama">
        </div>

        <div class="col-md-4 mb-4">
            <label for="exampleFormControlInput1" class="form-label">Tanggal Akhir</label>
            <input type="date" class="form-control" name="nama_wilayah" id="exampleFormControlInput1" placeholder="Masukkan Nama">
        </div>
    </div>

    </div>
    <div class="card-footer">
        <button type="submit" class="btn btn-md btn-primary">CETAK</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website_kas\website_kas\resources\views/admin/laporan/laporan_kas.blade.php ENDPATH**/ ?>