
<?php $__env->startSection('content'); ?>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Tambah Komisariat</h6>
        </div>
        <form action="<?php echo e(route('komisariat.store')); ?>" method="POST">
            <div class="card-body">
                <?php echo e(csrf_field()); ?>

                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Nama Komisariat</label>
                    <input type="text" class="form-control" name="nama_komisariat" id="exampleFormControlInput1"
                        placeholder="Masukkan Nama">
                </div>
                <div class="mb-3">
                    <label for="id_wilayah" class="form-label">Wilayah</label>
                    <select class="form-control" name="id_wilayah">
                        <option value="">Pilih Wilayah</option>
                        <?php $__currentLoopData = $wilayah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama_wilayah); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['thn_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-md btn-primary">SIMPAN</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\website_kas\website_kas\resources\views/admin/komisariat/add_komisariat.blade.php ENDPATH**/ ?>