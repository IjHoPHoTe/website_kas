<?php
header('Location : public/');

?>